<?php
extract($_POST);
echo "<script>location.href='../index.php?q=".$query."'</script>";
?>